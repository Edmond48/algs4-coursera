/* *****************************************************************************
 *  Name:
 *  Date:
 *  Description:
 **************************************************************************** */

import edu.princeton.cs.algs4.Picture;

public class SeamCarver {

    // the photo after edit
    private Picture carvedPic;

    // create a seam carver object based on the given picture
    public SeamCarver(Picture picture) {
        if (picture == null) throw new IllegalArgumentException("Null argument for constructor");
        this.carvedPic = new Picture(picture);
    }

    // current picture
    public Picture picture() {
        Picture picture = new Picture(carvedPic);
        return picture;
    }

    // width of current picture
    public int width() {
        return carvedPic.width();
    }

    // height of current picture
    public int height() {
        return carvedPic.height();
    }

    // energy of pixel at column x and row y
    public double energy(int x, int y) {
        // check for valid argument
        if (x < 0 || y < 0 || x >= carvedPic.width() || y >= carvedPic.height())
            throw new IllegalArgumentException("Pixel index out of bound");
        if (x == 0 || x == carvedPic.width() - 1 || y == 0 || y == carvedPic.height() - 1)
            return 1000.0;
        return Math.sqrt(deltaSquaredX(x, y) + deltaSquaredY(x, y));
    }

    // sequence of indices for horizontal seam
    public int[] findHorizontalSeam() {

        double[][] energy = new double[carvedPic.width()][carvedPic.height()];
        for (int i = 0; i < energy.length; i++) {
            for (int j = 0; j < energy[i].length; j++)
                energy[i][j] = energy(i, j);
        }

        double[][] distTo = new double[carvedPic.width()][carvedPic.height()];
        for (int i = 0; i < distTo.length; i++) {
            for (int j = 0; j < distTo[i].length; j++) {
                if (i == 0) distTo[i][j] = 1000.0;
                else distTo[i][j] = Double.POSITIVE_INFINITY;
            }
        }

        int[][] pathTo = new int[carvedPic.width()][carvedPic.height()];

        for (int x = 0; x < carvedPic.width() - 1; x++) {
            for (int y = 0; y < carvedPic.height(); y++) {
                if (distTo[x + 1][y] > distTo[x][y] + energy[x + 1][y]) {
                    distTo[x + 1][y] = distTo[x][y] + energy[x + 1][y];
                    pathTo[x + 1][y] = y;
                }

                if ((y != 0) && (distTo[x + 1][y - 1] > distTo[x][y] + energy[x + 1][y
                        - 1])) {
                    distTo[x + 1][y - 1] = distTo[x][y] + energy[x + 1][y - 1];
                    pathTo[x + 1][y - 1] = y;
                }

                if ((y != carvedPic.height() - 1) && (distTo[x + 1][y + 1] > distTo[x][y] + energy[x
                        + 1][y + 1])) {
                    distTo[x + 1][y + 1] = distTo[x][y] + energy[x + 1][y + 1];
                    pathTo[x + 1][y + 1] = y;
                }
            }
        }

        // the column of the last pixel in the seam
        int endY = 0;

        double min = distTo[carvedPic.width() - 1][0];
        for (int y = 0; y < carvedPic.height(); y++) {
            if (distTo[carvedPic.width() - 1][y] < min) {
                min = distTo[carvedPic.width() - 1][y];
                endY = y;
            }
        }

        int[] seam = new int[carvedPic.width()];
        seam[seam.length - 1] = endY;
        for (int x = seam.length - 2; x >= 0; x--) {
            seam[x] = pathTo[x + 1][seam[x + 1]];
        }
        return seam;
    }

    // sequence of indices for vertical seam
    public int[] findVerticalSeam() {

        double[][] energy = new double[carvedPic.width()][carvedPic.height()];
        for (int i = 0; i < energy.length; i++) {
            for (int j = 0; j < energy[i].length; j++)
                energy[i][j] = energy(i, j);
        }

        double[][] distTo = new double[carvedPic.width()][carvedPic.height()];
        for (int i = 0; i < distTo.length; i++) {
            for (int j = 0; j < distTo[i].length; j++) {
                if (j == 0) distTo[i][j] = 1000.0;
                else distTo[i][j] = Double.POSITIVE_INFINITY;
            }
        }

        int[][] pathTo = new int[carvedPic.width()][carvedPic.height()];

        for (int y = 0; y < carvedPic.height() - 1; y++) {
            for (int x = 0; x < carvedPic.width(); x++) {
                if (distTo[x][y + 1] > distTo[x][y] + energy[x][y + 1]) {
                    distTo[x][y + 1] = distTo[x][y] + energy[x][y + 1];
                    pathTo[x][y + 1] = x;
                }

                if ((x != 0) && (distTo[x - 1][y + 1] > distTo[x][y] + energy[x - 1][y + 1])) {
                    distTo[x - 1][y + 1] = distTo[x][y] + energy[x - 1][y + 1];
                    pathTo[x - 1][y + 1] = x;
                }

                if ((x != carvedPic.width() - 1) && (distTo[x + 1][y + 1] > distTo[x][y] + energy[x
                        + 1][y + 1])) {
                    distTo[x + 1][y + 1] = distTo[x][y] + energy[x + 1][y + 1];
                    pathTo[x + 1][y + 1] = x;
                }
            }
        }

        // the column of the last pixel in the seam
        int endX = 0;

        double min = distTo[0][carvedPic.height() - 1];
        for (int x = 0; x < carvedPic.width(); x++) {
            if (distTo[x][carvedPic.height() - 1] < min) {
                min = distTo[x][carvedPic.height() - 1];
                endX = x;
            }
        }

        int[] seam = new int[carvedPic.height()];
        seam[seam.length - 1] = endX;
        for (int y = seam.length - 2; y >= 0; y--) {
            seam[y] = pathTo[seam[y + 1]][y + 1];
        }
        return seam;
    }

    // remove horizontal seam from current picture
    public void removeHorizontalSeam(int[] seam) {
        if (carvedPic.height() <= 1) throw new IllegalArgumentException("Minimum picture width");
        checkHor(seam);
        Picture newPic = new Picture(carvedPic.width(), carvedPic.height() - 1);
        for (int x = 0; x < newPic.width(); x++) {
            int avoid = seam[x];
            for (int y = 0; y < carvedPic.height(); y++) {
                if (y < avoid) newPic.setRGB(x, y, carvedPic.getRGB(x, y));
                else if (y > avoid) newPic.setRGB(x, y - 1, carvedPic.getRGB(x, y));
            }
        }
        carvedPic = newPic;
    }

    // remove vertical seam from current picture
    public void removeVerticalSeam(int[] seam) {
        if (carvedPic.width() <= 1) throw new IllegalArgumentException("Minimum picture height");
        checkVer(seam);
        Picture newPic = new Picture(carvedPic.width() - 1, carvedPic.height());
        for (int y = 0; y < newPic.height(); y++) {
            int avoid = seam[y];
            for (int x = 0; x < carvedPic.width(); x++) {
                if (x < avoid) newPic.setRGB(x, y, carvedPic.getRGB(x, y));
                else if (x > avoid) newPic.setRGB(x - 1, y, carvedPic.getRGB(x, y));
            }
        }
        carvedPic = newPic;
    }

    // helper method to check argument of removeHorizontalSeam
    private void checkHor(int[] seam) {
        if (seam == null) throw new IllegalArgumentException("Argument can't be null");
        if (seam.length != width()) throw new IllegalArgumentException("Invalid array length");
        for (int i = 0; i < seam.length - 1; i++) {
            if (Math.abs(seam[i] - seam[i + 1]) > 1)
                throw new IllegalArgumentException("Invalid difference between pixel");
        }
    }

    // helper method to check argument of removeVerticalSeam
    private void checkVer(int[] seam) {
        if (seam == null) throw new IllegalArgumentException("Argument can't be null");
        if (seam.length != height()) throw new IllegalArgumentException("Invalid array length");
        for (int i = 0; i < seam.length - 1; i++) {
            if (Math.abs(seam[i] - seam[i + 1]) > 1)
                throw new IllegalArgumentException("Invalid difference between pixel");
        }
    }

    private double deltaSquaredX(int x, int y) {
        int rgb0 = carvedPic.getRGB(x - 1, y);
        int rbg1 = carvedPic.getRGB(x + 1, y);
        int r = ((rgb0 >> 16) & 0xFF) - ((rbg1 >> 16) & 0xFF);
        int g = ((rgb0 >> 8) & 0xFF) - ((rbg1 >> 8) & 0xFF);
        int b = ((rgb0) & 0xFF) - ((rbg1) & 0xFF);
        return (r * r + g * g + b * b) * 1.0;
    }

    private double deltaSquaredY(int x, int y) {
        int rgb0 = carvedPic.getRGB(x, y - 1);
        int rbg1 = carvedPic.getRGB(x, y + 1);
        int r = ((rgb0 >> 16) & 0xFF) - ((rbg1 >> 16) & 0xFF);
        int g = ((rgb0 >> 8) & 0xFF) - ((rbg1 >> 8) & 0xFF);
        int b = ((rgb0) & 0xFF) - ((rbg1) & 0xFF);
        return (r * r + g * g + b * b) * 1.0;
    }
}
